
// declare global variables here


function setup() {
  // put setup code here --> this runs once upon launch
  createCanvas(600, 500);

}


function draw() {
  // this loops over and over

}



// write custom functions here
